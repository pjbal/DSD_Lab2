/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "//homes.student.eecs.qmul.ac.uk/pjb30/Documents/DSD/LAB2/fourbitAdderSubtractor/TB_fourbitAdderSubtracto_VHDL.vhd";
extern char *IEEE_P_1242562249;

char *ieee_p_1242562249_sub_180853171_1035706684(char *, char *, int , int );


static void work_a_0594067001_2372691052_p_0(char *t0)
{
    char t15[16];
    char *t1;
    char *t2;
    int64 t3;
    char *t4;
    int t5;
    int t6;
    char *t7;
    char *t8;
    int t9;
    int t10;
    char *t11;
    char *t12;
    unsigned char t13;
    unsigned char t14;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    unsigned char t23;
    int t24;

LAB0:    t1 = (t0 + 2832U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(77, ng0);
    t3 = (100 * 1000LL);
    t2 = (t0 + 2640);
    xsi_process_wait(t2, t3);

LAB6:    *((char **)t1) = &&LAB7;

LAB1:    return;
LAB4:    xsi_set_current_line(79, ng0);
    t2 = (t0 + 5870);
    *((int *)t2) = 15;
    t4 = (t0 + 5874);
    *((int *)t4) = 0;
    t5 = 15;
    t6 = 0;

LAB8:    if (t5 >= t6)
        goto LAB9;

LAB11:    xsi_set_current_line(94, ng0);

LAB29:    *((char **)t1) = &&LAB30;
    goto LAB1;

LAB5:    goto LAB4;

LAB7:    goto LAB5;

LAB9:    xsi_set_current_line(80, ng0);
    t7 = (t0 + 5878);
    *((int *)t7) = 15;
    t8 = (t0 + 5882);
    *((int *)t8) = 0;
    t9 = 15;
    t10 = 0;

LAB12:    if (t9 >= t10)
        goto LAB13;

LAB15:
LAB10:    t2 = (t0 + 5870);
    t5 = *((int *)t2);
    t4 = (t0 + 5874);
    t6 = *((int *)t4);
    if (t5 == t6)
        goto LAB11;

LAB26:    t9 = (t5 + -1);
    t5 = t9;
    t7 = (t0 + 5870);
    *((int *)t7) = t5;
    goto LAB8;

LAB13:    xsi_set_current_line(81, ng0);
    t11 = (t0 + 5886);
    *((unsigned char *)t11) = (unsigned char)2;
    t12 = (t0 + 5887);
    *((unsigned char *)t12) = (unsigned char)3;
    t13 = (unsigned char)2;
    t14 = (unsigned char)3;

LAB16:    if (t13 <= t14)
        goto LAB17;

LAB19:
LAB14:    t2 = (t0 + 5878);
    t9 = *((int *)t2);
    t4 = (t0 + 5882);
    t10 = *((int *)t4);
    if (t9 == t10)
        goto LAB15;

LAB25:    t24 = (t9 + -1);
    t9 = t24;
    t7 = (t0 + 5878);
    *((int *)t7) = t9;
    goto LAB12;

LAB17:    xsi_set_current_line(84, ng0);
    t16 = (t0 + 5870);
    t17 = ieee_p_1242562249_sub_180853171_1035706684(IEEE_P_1242562249, t15, *((int *)t16), 4);
    t18 = (t0 + 3216);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    t21 = (t20 + 56U);
    t22 = *((char **)t21);
    memcpy(t22, t17, 4U);
    xsi_driver_first_trans_fast(t18);
    xsi_set_current_line(85, ng0);
    t2 = (t0 + 5878);
    t4 = ieee_p_1242562249_sub_180853171_1035706684(IEEE_P_1242562249, t15, *((int *)t2), 4);
    t7 = (t0 + 3280);
    t8 = (t7 + 56U);
    t11 = *((char **)t8);
    t12 = (t11 + 56U);
    t16 = *((char **)t12);
    memcpy(t16, t4, 4U);
    xsi_driver_first_trans_fast(t7);
    xsi_set_current_line(86, ng0);
    t2 = (t0 + 5886);
    t4 = (t0 + 3344);
    t7 = (t4 + 56U);
    t8 = *((char **)t7);
    t11 = (t8 + 56U);
    t12 = *((char **)t11);
    *((unsigned char *)t12) = *((unsigned char *)t2);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(88, ng0);
    t3 = (100 * 1000LL);
    t2 = (t0 + 2640);
    xsi_process_wait(t2, t3);

LAB22:    *((char **)t1) = &&LAB23;
    goto LAB1;

LAB18:    t2 = (t0 + 5886);
    t13 = *((unsigned char *)t2);
    t4 = (t0 + 5887);
    t14 = *((unsigned char *)t4);
    if (t13 == t14)
        goto LAB19;

LAB24:    t23 = (t13 + (unsigned char)1);
    t13 = t23;
    t7 = (t0 + 5886);
    *((unsigned char *)t7) = t13;
    goto LAB16;

LAB20:    goto LAB18;

LAB21:    goto LAB20;

LAB23:    goto LAB21;

LAB27:    goto LAB2;

LAB28:    goto LAB27;

LAB30:    goto LAB28;

}


extern void work_a_0594067001_2372691052_init()
{
	static char *pe[] = {(void *)work_a_0594067001_2372691052_p_0};
	xsi_register_didat("work_a_0594067001_2372691052", "isim/TB_fourbitAdderSubtracto_VHDL_isim_beh.exe.sim/work/a_0594067001_2372691052.didat");
	xsi_register_executes(pe);
}
