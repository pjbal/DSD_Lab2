/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "//homes.student.eecs.qmul.ac.uk/pjb30/Documents/DSD/LAB2/FourBitLACAdder/TB_nbit_Adder_VHDL.vhd";
extern char *IEEE_P_1242562249;

char *ieee_p_1242562249_sub_180853171_1035706684(char *, char *, int , int );


static void work_a_2355505586_2372691052_p_0(char *t0)
{
    char t33[16];
    char *t1;
    char *t2;
    int64 t3;
    char *t4;
    int t5;
    char *t6;
    int t7;
    int t8;
    int t9;
    char *t10;
    int t11;
    int t12;
    char *t13;
    char *t14;
    int t15;
    char *t16;
    int t17;
    int t18;
    int t19;
    char *t20;
    int t21;
    int t22;
    char *t23;
    char *t24;
    int t25;
    char *t26;
    int t27;
    int t28;
    int t29;
    char *t30;
    int t31;
    int t32;
    char *t34;
    char *t35;
    char *t36;
    int t37;
    char *t38;
    char *t39;
    char *t40;
    char *t41;
    char *t42;

LAB0:    t1 = (t0 + 2952U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(85, ng0);
    t3 = (100 * 1000LL);
    t2 = (t0 + 2760);
    xsi_process_wait(t2, t3);

LAB6:    *((char **)t1) = &&LAB7;

LAB1:    return;
LAB4:    xsi_set_current_line(88, ng0);
    t2 = (t0 + 1968U);
    t4 = *((char **)t2);
    t5 = *((int *)t4);
    t2 = (t0 + 1968U);
    t6 = *((char **)t2);
    t7 = *((int *)t6);
    t8 = (t5 * t7);
    t9 = (t8 - 1);
    t2 = (t0 + 5940);
    *((int *)t2) = t9;
    t10 = (t0 + 5944);
    *((int *)t10) = 0;
    t11 = t9;
    t12 = 0;

LAB8:    if (t11 >= t12)
        goto LAB9;

LAB11:    xsi_set_current_line(103, ng0);

LAB29:    *((char **)t1) = &&LAB30;
    goto LAB1;

LAB5:    goto LAB4;

LAB7:    goto LAB5;

LAB9:    xsi_set_current_line(89, ng0);
    t13 = (t0 + 1968U);
    t14 = *((char **)t13);
    t15 = *((int *)t14);
    t13 = (t0 + 1968U);
    t16 = *((char **)t13);
    t17 = *((int *)t16);
    t18 = (t15 * t17);
    t19 = (t18 - 1);
    t13 = (t0 + 5948);
    *((int *)t13) = t19;
    t20 = (t0 + 5952);
    *((int *)t20) = 0;
    t21 = t19;
    t22 = 0;

LAB12:    if (t21 >= t22)
        goto LAB13;

LAB15:
LAB10:    t2 = (t0 + 5940);
    t11 = *((int *)t2);
    t4 = (t0 + 5944);
    t12 = *((int *)t4);
    if (t11 == t12)
        goto LAB11;

LAB26:    t5 = (t11 + -1);
    t11 = t5;
    t6 = (t0 + 5940);
    *((int *)t6) = t11;
    goto LAB8;

LAB13:    xsi_set_current_line(90, ng0);
    t23 = (t0 + 1968U);
    t24 = *((char **)t23);
    t25 = *((int *)t24);
    t23 = (t0 + 1968U);
    t26 = *((char **)t23);
    t27 = *((int *)t26);
    t28 = (t25 * t27);
    t29 = (t28 - 1);
    t23 = (t0 + 5956);
    *((int *)t23) = t29;
    t30 = (t0 + 5960);
    *((int *)t30) = 0;
    t31 = t29;
    t32 = 0;

LAB16:    if (t31 >= t32)
        goto LAB17;

LAB19:
LAB14:    t2 = (t0 + 5948);
    t21 = *((int *)t2);
    t4 = (t0 + 5952);
    t22 = *((int *)t4);
    if (t21 == t22)
        goto LAB15;

LAB25:    t5 = (t21 + -1);
    t21 = t5;
    t6 = (t0 + 5948);
    *((int *)t6) = t21;
    goto LAB12;

LAB17:    xsi_set_current_line(93, ng0);
    t34 = (t0 + 5940);
    t35 = (t0 + 1968U);
    t36 = *((char **)t35);
    t37 = *((int *)t36);
    t35 = ieee_p_1242562249_sub_180853171_1035706684(IEEE_P_1242562249, t33, *((int *)t34), t37);
    t38 = (t0 + 3336);
    t39 = (t38 + 56U);
    t40 = *((char **)t39);
    t41 = (t40 + 56U);
    t42 = *((char **)t41);
    memcpy(t42, t35, 4U);
    xsi_driver_first_trans_fast(t38);
    xsi_set_current_line(94, ng0);
    t2 = (t0 + 5948);
    t4 = (t0 + 1968U);
    t6 = *((char **)t4);
    t5 = *((int *)t6);
    t4 = ieee_p_1242562249_sub_180853171_1035706684(IEEE_P_1242562249, t33, *((int *)t2), t5);
    t10 = (t0 + 3400);
    t13 = (t10 + 56U);
    t14 = *((char **)t13);
    t16 = (t14 + 56U);
    t20 = *((char **)t16);
    memcpy(t20, t4, 4U);
    xsi_driver_first_trans_fast(t10);
    xsi_set_current_line(95, ng0);
    t2 = (t0 + 5956);
    t4 = (t0 + 1968U);
    t6 = *((char **)t4);
    t5 = *((int *)t6);
    t4 = ieee_p_1242562249_sub_180853171_1035706684(IEEE_P_1242562249, t33, *((int *)t2), t5);
    t10 = (t0 + 3464);
    t13 = (t10 + 56U);
    t14 = *((char **)t13);
    t16 = (t14 + 56U);
    t20 = *((char **)t16);
    memcpy(t20, t4, 4U);
    xsi_driver_first_trans_fast(t10);
    xsi_set_current_line(97, ng0);
    t3 = (100 * 1000LL);
    t2 = (t0 + 2760);
    xsi_process_wait(t2, t3);

LAB22:    *((char **)t1) = &&LAB23;
    goto LAB1;

LAB18:    t2 = (t0 + 5956);
    t31 = *((int *)t2);
    t4 = (t0 + 5960);
    t32 = *((int *)t4);
    if (t31 == t32)
        goto LAB19;

LAB24:    t5 = (t31 + -1);
    t31 = t5;
    t6 = (t0 + 5956);
    *((int *)t6) = t31;
    goto LAB16;

LAB20:    goto LAB18;

LAB21:    goto LAB20;

LAB23:    goto LAB21;

LAB27:    goto LAB2;

LAB28:    goto LAB27;

LAB30:    goto LAB28;

}


extern void work_a_2355505586_2372691052_init()
{
	static char *pe[] = {(void *)work_a_2355505586_2372691052_p_0};
	xsi_register_didat("work_a_2355505586_2372691052", "isim/TB_nbit_Adder_VHDL_isim_beh.exe.sim/work/a_2355505586_2372691052.didat");
	xsi_register_executes(pe);
}
